import org.openqa.selenium.By;
import org.openqa.selenium.By;


import org.openqa.selenium.WebDriver;

	import java.util.concurrent.TimeUnit;
	import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class new_test_case {
	

	


    public static void main(String[] args) {
 	   
 	   
        // objects and variables instantiation

            //WebDriver driver = new FirefoxDriver();
    	
    	System.setProperty("webdriver.chrome.driver", "Browser_Drivers/chromedriver.exe");
		ChromeDriver  driver=new ChromeDriver();
		TimeUnit tu=TimeUnit.SECONDS;
		//driverObj.manage().timeouts().implicitlyWait(30,tu);
		driver.manage().timeouts().implicitlyWait(30,tu);

            
            
            
            String appUrl = "https://1800flowers.ca/signin";

       // launch the firefox browser and open the application url

            driver.get(appUrl);

      // maximize the browser window

            driver.manage().window().maximize();

      // declare and initialize the variable to store the expected title of the webpage.

           String expectedTitle = "Sign In | 1-800-Flowers.ca";

      // fetch the title of the web page and save it into a string variable

           String actualTitle = driver.getTitle();

     // compare the expected title of the page with the actual title of the page and print the result

            if (expectedTitle.equals(actualTitle))

            {

                  System.out.println("Verification Successful - The correct title is displayed on the web page.");

            }
           else

            {

                   System.out.println("Verification Failed - An incorrect title is displayed on the web page.");
            }


 // enter a valid username in the email textbox

         WebElement username = driver.findElement(By.name("username"));
         username.clear();
         username.sendKeys("karan");
         
// enter a valid password in the password textbox

         WebElement password = driver.findElement(By.name("password"));
         password.clear();
         password.sendKeys("borntowin");

// click on the Sign in button

          WebElement SignInButton = driver.findElement(By.name("signin"));
          SignInButton.click();
             
   // Title matching after logged in          
             
          String expectedTitle1 = "My Account | 1-800-Flowers.ca";
          String actualTitle1 = driver.getTitle();
             
          if (expectedTitle1.equals(actualTitle1))

        {

              System.out.println("Verification Successful - Test case1 executed successfully.");
              
        }
        
          else
          	
       {

               System.out.println("Verification Failed - Test case1 is Failed");
        }  
        
          // logout the account     
          
          driver.findElement(By.linkText("Logout")).click();
          
      //    webdriver.navigate().back();
    
          driver.findElement(By.linkText("Sign in")).click();
          
          
         // Enter invalid username and password    
            
            
            WebElement username1 = driver.findElement(By.name("username"));
            username1.clear();
            username1.sendKeys("dfggf");
            
            WebElement password1 = driver.findElement(By.name("password"));
            password1.clear();
            password1.sendKeys("born");
            
            WebElement SignInButton1 = driver.findElement(By.name("signin"));    
            SignInButton1.click();
            
            String expectedTitle2 = "Sign In | 1-800-Flowers.ca";
            String actualTitle2 = driver.getTitle();
            
           if (expectedTitle2.equals(actualTitle2))

       {

             System.out.println("Verification Successful - Test case2 executed successfully.");
             
       }
           
       else
      	 
      {

              System.out.println("Verification Failed - Test case2 is Failed");
       }    
           
           
        // Sign-in with valid user name and invalid password
           
           WebElement username2 = driver.findElement(By.name("username"));
           username2.clear();
           username2.sendKeys("karan");
           
           WebElement password2 = driver.findElement(By.name("password"));
           password2.clear();
           password2.sendKeys("born");
           
           WebElement SignInButton2 = driver.findElement(By.name("signin"));    
           SignInButton2.click();
           
   // Checking the test executed or not   
           String expectedTitle3 = "Sign In | 1-800-Flowers.ca";
           String actualTitle3 = driver.getTitle();
           
          if (expectedTitle3.equals(actualTitle3))

      {

            System.out.println("Verification Successful - Test case3 executed successfully.");
            
      }
          
      else
     {

             System.out.println("Verification Failed - Test case3 is Failed");
      }    
       
          // Sign-in with valid user name and empty password
          
          WebElement username3 = driver.findElement(By.name("username"));
          username3.clear();
          username3.sendKeys("karan");
          
          WebElement password3 = driver.findElement(By.name("password"));
          password3.clear();
          password3.sendKeys("");
          
          WebElement SignInButton3 = driver.findElement(By.name("signin"));
          SignInButton3.click();
          
  // Checking the test executed or not   
          String expectedTitle4 = "Sign In | 1-800-Flowers.ca";
          String actualTitle4 = driver.getTitle();
          
         if (expectedTitle4.equals(actualTitle4))

     {

           System.out.println("Verification Successful - Test case4 executed successfully.");
           
     }
         
     else
    {

            System.out.println("Verification Failed - Test case4 is Failed");
     } 
         
         // Sign-in with empty user name and valid password
         
         WebElement username4 = driver.findElement(By.name("username"));
         username4.clear();
         username4.sendKeys("");
         
         WebElement password4 = driver.findElement(By.name("password"));
         password4.clear();
         password4.sendKeys("borntowin");
         
         WebElement SignInButton4 = driver.findElement(By.name("signin"));    
         SignInButton4.click();
         
 // Checking the test executed or not  
         
         String expectedTitle5 = "Sign In | 1-800-Flowers.ca";
         String actualTitle5 = driver.getTitle();
         
        if (expectedTitle5.equals(actualTitle5))

    {

          System.out.println("Verification Successful - Test case5 executed successfully.");
          
    }
        
    else
   {

           System.out.println("Verification Failed - Test case5 is Failed");
    } 
        
       // Enter username and password with capslock on
        
        WebElement username5 = driver.findElement(By.name("username"));
        username5.clear();
        username5.sendKeys("KARAN");
        
        WebElement password5 = driver.findElement(By.name("password"));
        password5.clear();
        password5.sendKeys("BORNTOWIN");
        
        WebElement SignInButton5 = driver.findElement(By.name("signin"));    
        SignInButton5.click();
        
// Checking the test executed or not   
        String expectedTitle6 = "Sign In | 1-800-Flowers.ca";
        String actualTitle6 = driver.getTitle();
        
       if (expectedTitle6.equals(actualTitle6))

   {

         System.out.println("Verification Successful - Test case6 executed successfully.");
         
   }
       
   else
  {

          System.out.println("Verification Failed - Test case6 is Failed");
          driver.findElement(By.linkText("Logout")).click();
          driver.findElement(By.linkText("Sign in")).click();
          
   }        
       // Title matching after logged in          
       
       String expectedTitle7 = "My Account | 1-800-Flowers.ca";
       String actualTitle7 = driver.getTitle();
       
      if (expectedTitle7.equals(actualTitle7))

  {

        System.out.println("Verification Successful - Test case7 executed successfully.");
        
  }
      
      
 else
 {

         System.out.println("Verification Failed - Test case7 is Failed");
  }  
  
//     driver.findElement(By.linkText("Logout")).click();  
 //   driver.close();
    
    WebDriver driver1 = new FirefoxDriver();

    String appUrl1 = "https://qa.1800flowers.ca/myaccount";

// launch the firefox browser and open the application url

    driver1.get(appUrl1);

//maximize the browser window

    driver1.manage().window().maximize();
    String expectedTitle8 = "My Account | 1-800-Flowers.ca";
    String actualTitle8 = driver.getTitle();
    
   if (expectedTitle8.equals(actualTitle8))

{

     System.out.println("Verification Successful - Test case8 executed failed.");
     
}
   
   
else
{

      System.out.println("Verification Failed - Test case8 executed successfully");
}  
    
    

//close the web browser

            driver.close();

            System.out.println("Test script executed successfully.");

            

//terminate the program
            System.exit(0);
     }

}


