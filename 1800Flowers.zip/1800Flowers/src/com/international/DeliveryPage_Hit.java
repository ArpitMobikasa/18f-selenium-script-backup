package com.international;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class DeliveryPage_Hit {
	
	ChromeDriver driverobj;
	WebDriverWait wait;

	@Test
	public void fn_checkout_ca() throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:\\WORKSPACE\\1800Flowers\\Browser_Drivers\\chromedriver.exe");
		driverobj= new ChromeDriver();
		
		TimeUnit tu = TimeUnit.SECONDS;
		driverobj.manage().timeouts().implicitlyWait(50,tu);
		
		//open the website
		
		driverobj.get("http://qa.0800flowers.com");
		Thread.sleep(5000);
		
		driverobj.manage().window().maximize();
		
		
		driverobj.findElement(By.xpath("/html/body/div[1]/div[4]/div[1]/div[2]/form/input[2]")).sendKeys("I");
		Thread.sleep(7000);
		
		driverobj.findElement(By.xpath("/html/body/div[3]/div")).click();
		Thread.sleep(5000);
		
		driverobj.findElement(By.xpath("/html/body/div[2]/div[4]/div[3]/div[2]/div[2]/div/div[1]/div[1]/a/img")).click();
		Thread.sleep(5000);
		
		/*driverobj.findElement(By.xpath("/html/body/div[1]/div[5]/div[3]/div[3]/form/a")).click();
		Thread.sleep(5000);*/
		
		driverobj.findElement(By.xpath("/html/body/div[1]/div[5]/div[3]/div[3]/div[2]/div/div/div[1]/ul/li[3]/a")).click();
		Thread.sleep(5000);
		
		driverobj.findElement(By.xpath("/html/body/div[1]/div[5]/div[3]/div[3]/form/a")).click();
		Thread.sleep(5000);
		
		driverobj.findElement(By.xpath("/html/body/div[1]/div[5]/div[8]/div[2]/a")).click();
		Thread.sleep(5000);
		
		driverobj.findElement(By.xpath("/html/body/div[2]/form[1]/div[5]/div/div[2]/div/div[1]/p[2]/label")).click();
		Thread.sleep(5000);
		
		driverobj.findElement(By.xpath("/html/body/div[2]/form[1]/div[6]/div/a/input")).click();
		Thread.sleep(5000);
		
		try
		{
			driverobj.findElement(By.xpath("/html/body/div[2]/form[1]/div[3]/div/div[2]/div[2]/div[3]/div[1]/input")).click();
			driverobj.findElement(By.xpath("/html/body/div[2]/form[1]/div[3]/div/div[2]/div[2]/div[3]/div[1]/input")).sendKeys("First Name");
			System.out.println("Test Passed");
			
		}catch(Exception e)
		{
				Reporter.log("Failed Step:  Error on Delivery Page");
		}
		
		
		
	}
	
	
	
		@AfterTest

		public void TearDown()
		{
			driverobj.close();
		    driverobj.quit();
		  
			
		}


}
