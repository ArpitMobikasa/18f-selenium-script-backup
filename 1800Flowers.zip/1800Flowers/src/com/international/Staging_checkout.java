package com.international;

import java.awt.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Staging_checkout {
	
ChromeDriver driverobj;
WebDriverWait wait;

@Test
public void fn_checkout_ca() throws InterruptedException
{
	WebDriver driver;
	System.setProperty("webdriver.chrome.driver", "C:\\WORKSPACE\\1800Flowers\\Browser_Drivers\\chromedriver.exe");
	driverobj= new ChromeDriver();
	
	TimeUnit tu = TimeUnit.SECONDS;
	driverobj.manage().timeouts().implicitlyWait(50,tu);
	
	//open the website
	
	driverobj.get("http://qa.0800flowers.com");
	Thread.sleep(5000);
	
	driverobj.manage().window().maximize();
	
	//select the delivery country using google API
	driverobj.findElement(By.xpath("/html/body/div[1]/div[4]/div[1]/div[2]/form/input[2]")).sendKeys("A");
	
	Thread.sleep(1000);
	
	driverobj.findElement(By.xpath("/html/body/div[3]/div")).click();
	//Done
	
	
	//Select the delivery province using google API 
	driverobj.findElement(By.xpath("/html/body/div[1]/div[4]/div[1]/div[2]/form/input[5]")).sendKeys("Perth");
	Thread.sleep(1000);
	
	driverobj.findElement(By.xpath("/html/body/div[9]/div[1]")).click();
	
	driverobj.findElement(By.xpath("/html/body/div[2]/div[1]/nav/div/div[2]/div[2]/div[2]/div/ul/li[1]/a[1]/span")).click();
	Thread.sleep(5000);
	
	driverobj.findElement(By.xpath("/html/body/div[2]/div[1]/nav/div/div[1]/div/div[1]/div[1]/div/form/input[2]")).sendKeys("anuj@mobikasa.com");
	driverobj.findElement(By.xpath("/html/body/div[2]/div[1]/nav/div/div[1]/div/div[1]/div[1]/div/form/input[3]")).sendKeys("mobikasa");
	Thread.sleep(5000);
	driverobj.findElement(By.xpath("/html/body/div[2]/div[1]/nav/div/div[1]/div/div[1]/div[1]/div/form/input[4]")).click();
	
	Thread.sleep(5000);
	
	driverobj.findElement(By.xpath("/html/body/div[2]/div[1]/nav/div/div[2]/div[2]/div[1]/ul/li[1]/a[1]")).click();
	Thread.sleep(5000);
	
	WebElement Root_Menu = driverobj.findElement(By.xpath("/html/body/div[2]/div[1]/nav/div/div[2]/div[2]/div[1]/ul/li[3]/a"));
	WebElement Child_Menu = driverobj.findElement(By.xpath("/html/body/div[2]/div[1]/nav/div/div[2]/div[2]/div[1]/ul/li[3]/div/ul/li[2]/a"));
	Actions act = new Actions(driverobj);
	act.moveToElement(Root_Menu).build().perform();
	Child_Menu.click();
	
	Thread.sleep(5000);
	//check Delivery Type filter
	driverobj.findElement(By.xpath("/html/body/div[2]/div[4]/div[3]/div[1]/form/div/div[3]/ul/li/label")).click();
	Thread.sleep(5000);
	driverobj.findElement(By.xpath("/html/body/div[2]/div[4]/div[3]/div[1]/form/div/div[3]/ul/li/label")).click();
	Thread.sleep(5000);
	
	
	//check price filter No. 1
	driverobj.findElement(By.xpath("/html/body/div[2]/div[4]/div[3]/div[1]/form/div/div[6]/ul/li[1]/label")).click();
	Thread.sleep(5000);	
	driverobj.findElement(By.xpath("/html/body/div[2]/div[4]/div[3]/div[1]/form/div/div[6]/ul/li[1]/label")).click();
	Thread.sleep(5000);
	
	//check price filter No. 2
	driverobj.findElement(By.xpath("/html/body/div[2]/div[4]/div[3]/div[1]/form/div/div[6]/ul/li[2]/label")).click();
	Thread.sleep(5000);	
	driverobj.findElement(By.xpath("/html/body/div[2]/div[4]/div[3]/div[1]/form/div/div[6]/ul/li[2]/label")).click();
	Thread.sleep(5000);
	
	//check price filter No. 3
	driverobj.findElement(By.xpath("/html/body/div[2]/div[4]/div[3]/div[1]/form/div/div[6]/ul/li[3]/label")).click();
	Thread.sleep(5000);	
	driverobj.findElement(By.xpath("/html/body/div[2]/div[4]/div[3]/div[1]/form/div/div[6]/ul/li[3]/label")).click();
	Thread.sleep(5000);
}

@AfterTest

public void TearDown()
{
	driverobj.close();
    driverobj.quit();
  
	
}




}
