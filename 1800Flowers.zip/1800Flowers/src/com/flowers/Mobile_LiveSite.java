package com.flowers;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Mobile_LiveSite {
	
	
	
	WebDriver driverObj=null;
	WebDriverWait wait;
	@Test
	public  void Mobile_Live() throws InterruptedException, ParseException  {
		System.setProperty("webdriver.chrome.driver", "C:\\WORKSPACE\\1800Flowers\\Browser_Drivers/chromedriver.exe");
		//DesiredCapabilities capabilities = DesiredCapabilities.chrome();
	    //capabilities.setCapability("chrome.switches", Arrays.asList("--incognito"));
	    //driverObj = new ChromeDriver(capabilities);
		
		
		 Map<String, String> mobileEmulation = new HashMap<String, String>();
		    mobileEmulation.put("deviceName", "Apple iPhone 6");
		    Map<String, Object> chromeOptions = new HashMap<String, Object>();
		    chromeOptions.put("mobileEmulation", mobileEmulation);
		    DesiredCapabilities dc = DesiredCapabilities.chrome();
		    dc.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
		   	driverObj = new ChromeDriver(dc);
		
		//driverObj = new ChromeDriver();
		
	    //WebDriver driverObj = new FirefoxDriver();
		
		
		//WebDriver driverObj = new FirefoxDriver(); 
		
		TimeUnit tu=TimeUnit.SECONDS;
		
		driverObj.manage().timeouts().implicitlyWait(150,tu);
		//driverObj.manage().timeouts().pageLoadTimeout(100,tu);
		try{
		driverObj.manage().window().maximize();
		}catch(Exception e)
		{
			Reporter.log("Failed Step:  Browser does not get load properly");
		}
		driverObj.get("http://m.www.1800flowers.com");
		Calendar cal = Calendar.getInstance();
		//Reporter.log("Test Case Start Time in IST:\n    " +cal.getTime());
	
		 /*Date date = new Date();
		 DateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		 timeFormat.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		 String estTime = timeFormat.format(date);		 
		 date = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss", Locale.ENGLISH).parse(estTime);
		 Reporter.log("Test Case Start Time in EST:    "+ "\n "+date);
		 System.out.println("Test Case Start Time in EST:    "+ "\n "+date);*/
		
		String tzid = "America/New_York";
	    TimeZone tz = TimeZone.getTimeZone(tzid);

	    long utc = System.currentTimeMillis();
	    Date d = new Date(utc);

	  
	   DateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm a z");
	

	    
	   System.err.println(format.format(d));

	   
	    format.setTimeZone(tz);
	    System.err.println(format.format(d));
	    Reporter.log("Test Case Start Time in EDT:    "+ "\n "+format.format(d));
		
		
		Thread.sleep(12000);
		//driverObj.navigate().refresh();
		 WebDriverWait wait = new WebDriverWait(driverObj, 150);
		 //Thread.sleep(12000);
		 try{
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='menu_btn']"))).click();
		 }catch(Exception e)
			{
				Reporter.log("Failed Step:  Menu button does not load on the page");
			}
		 //wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='sprites-fw_search-menu-dark']"))).click();
		// WebElement hiddenelement=driverObj.findElement(By.xpath("//a[@id='menu_btn']"));
			//WebElement hiddenelement=driverObj.findElement(By.xpath("//div[@class='sprites-fw_search-menu-dark']"));
			//JavascriptExecutor js = (JavascriptExecutor)driverObj; 
			//js.executeScript("arguments[0].click();", hiddenelement);
		 
		//driverObj.findElement(By.xpath("//div[@class='sprites-fw_search-menu-dark']")).click();
		Thread.sleep(2000);
		try{
		//driverObj.findElement(By.xpath("//a[@id='_link_custom-cruy-0yce']")).click();
		//driverObj.findElement(By.xpath("//div[contains(text(),'Birthday')]")).click();
		driverObj.findElement(By.id("18F_TopNavEspot2")).click();
		driverObj.findElement(By.xpath("//a[contains(text(),'All Birthday Gifts')]")).click();
		}catch(Exception e)
		{
			Reporter.log("Failed Step:  Not able to Click on Sub-Menu");
		}
		
		Thread.sleep(8000);
		//wait.until(ExpectedConditions.visibilityOf(driverObj.findElement(By.xpath("a[@id='menu_btn']"))));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='menu_btn']"))).click();
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='home_search']/form[2]/div[1]/div/input"))).click();
		Thread.sleep(3000);
		try{
		//driverObj.findElement(By.xpath("//input[@class='check_val override']")).sendKeys("Fields of Europe");
		driverObj.findElement(By.xpath("//input[@data-id='SearchBox']")).sendKeys("Fields of Europe");
		}catch(Exception e)
		{
			Reporter.log("Failed Step:  'Search by sku or keyword' textbox have some issue");
		}
		Thread.sleep(2000);
		//driverObj.findElement(By.className("secondary_bg-search_btn-small")).click();
		driverObj.findElement(By.xpath("//*[@id='_menu_slide']/form[2]/div[1]/button")).click();
		Thread.sleep(12000);
		try{
			//driverObj.findElement(By.xpath("//a[@href='//m.www.1800flowers.com/fields-of-europe-90977']")).click();
			driverObj.findElement(By.xpath("//img[@alt='Fields of Europe�']")).click();
			//driverObj.findElement(By.xpath("//a[contains(text(),'Fields of Europe� Happy Birthday')]")).click();
		//driverObj.findElement(By.xpath("//a[@name='product2']")).click();
		}catch(Exception e)
		{
			Reporter.log("Failed Step:  Product does not get load on the Page");
		}
		Thread.sleep(8000);
		try{
		driverObj.findElement(By.xpath("//span[contains(text(),'Love it') or contains(text(),'Medium') or contains(text(),'Premium' )]")).click();
		//driverObj.findElement(By.xpath("//span[contains(text(),'Love it' or contains(text(),'Medium' or contains(text(),'Premium' )]")).click();
		}catch(Exception e)
		{
			Reporter.log("Failed Step:  PDP Page do not get load properly");
		}
		 JavascriptExecutor jse = (JavascriptExecutor)driverObj;
		 jse.executeScript("window.scrollBy(0,250)", "");
		 Thread.sleep(5000);
		 
		 try{
		 driverObj.findElement(By.xpath("//input[@data-id='zipCode']")).sendKeys("11514");
		 }catch(Exception e)
			{
				Reporter.log("Failed Step:  Zipcode Textbox does not get Load at the Page");
			}
		 Thread.sleep(5000);
		
		 driverObj.findElement(By.xpath("//div[@class='input_overlay']")).click();
		 
		 /*try{
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='input_overlay']"))).click();	 
		 //driverObj.findElement(By.xpath("//div[@class='input_overlay12345']")).click();
		 }catch(Exception e)
		 {
			 Reporter.log("Test Case Failed:  Select Delivery Date button does not get Load at the Page"); 
		 }
		 Thread.sleep(8000);*/
		 
		//WebDriverWait wait = new WebDriverWait(driverObj, 20);
		
		 
		 Date now = new Date();
		DateFormat ord_date = new SimpleDateFormat("dd-MM-yyyy");
		
		cal.setTime(now);
		
		cal.add(Calendar.DAY_OF_YEAR,22);
		Date randomdate = cal.getTime();
		
		String t = ord_date.format(randomdate);
		System.out.println(" Random date: "+t);
			
			
		String[] date1 = t.split("-");
		String date2=date1[0];
		int random_date = Integer.parseInt(date2);
	
		
		
		
		String final1="month1day"+random_date;
		System.out.println("future date: "+final1);
		System.out.println(final1);
		String final2="month2day"+random_date;
		System.out.println("future date: "+final2);
		System.out.println(final2);
		Thread.sleep(3000);
		try{
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@id,'"+final1+"') or contains(@id,'"+final2+"')]"))).click();
		//wait.until(ExpectedConditions.elementToBeClickable(By.id(final1))).click();
		}catch(Exception e)
		{
			Reporter.log("Test Case Failed:  Either Date is not clickable or Product is out of stock");
		}
		
		//Thread.sleep(5000);
		//jse.executeScript("window.scrollBy(0,10)", "");
		
		/*WebElement element = driverObj.findElement(By.xpath("//button[@class='secondary_bg _new_checkout arrow light has_icon']"));
		JavascriptExecutor buyButton = (JavascriptExecutor)driverObj; 
		buyButton.executeScript("arguments[0].click();", element);*/
		
		
		Thread.sleep(12000);
		//driverObj.findElement(By.xpath("//input[@data-id='firstName']")).clear();
		//String Element1=driverObj.findElement(By.xpath("//input[@data-id='firstName']")).getText();
		//System.out.println(Element1);
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@data-id='firstName']"))).sendKeys("test");
		 try{
	     WebElement focus=driverObj.findElement(By.xpath("//input[@data-id='firstName']"));
	     focus.sendKeys("");
	     focus.sendKeys("test");
	     }catch(Exception e)
			{
				Reporter.log("Failed Step:  FirstName textox does not get load, Due to this error on the page after submit the button ");
			}
	     driverObj.findElement(By.xpath("//input[@data-id='lastName']")).clear();
	     driverObj.findElement(By.xpath("//input[@data-id='lastName']")).sendKeys("Order");
	     driverObj.findElement(By.xpath("//input[@data-id='QAS_lineone']")).clear();
	     driverObj.findElement(By.xpath("//input[@data-id='QAS_lineone']")).sendKeys("One Old Country Road");
	     driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_phone1_1']")).sendKeys("5162374674");
	     try{
	     driverObj.findElement(By.xpath("//textarea[@data-id='giftMessages_1']")).sendKeys("Test script, please do not fulfill order");
	     }catch(Exception e)
			{
				Reporter.log("Failed Step:  'GiftMessage' TextBox does not get load ");
			}
	     try{
	     driverObj.findElement(By.xpath("//a[@id='_proceed_to_checkout']")).click();
	     }catch(Exception e)
			{
				Reporter.log("Failed Step:  Not able to click on next button for Checkout ");
			}
	     
	     Thread.sleep(12000);
	     try{
	     driverObj.findElement(By.xpath("//a[@class='fake_button hollow_button centered small']")).click();
	     }catch(Exception e)
			{
				Reporter.log("Failed Step:  Not able to click on address is Correct button ");
			}
	     
	     Thread.sleep(12000);
	     try{
	     driverObj.findElement(By.xpath("//input[@data-id='account']")).sendKeys("4111111111111111");
	     driverObj.findElement(By.xpath("//input[@data-id='cc_nameoncard']")).sendKeys("Test Order");
	     Select year = new Select(driverObj.findElement(By.xpath("//select[@data-id='expire_month']")));
	        year.selectByVisibleText("12");
	        Select month = new Select(driverObj.findElement(By.xpath("//select[@data-id='expire_year']")));
	        month.selectByVisibleText("2020");
	        Thread.sleep(1000);
	        driverObj.findElement(By.xpath("//input[@data-id='securitycode']")).sendKeys("123");
	        
	        driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_firstName_1']")).clear();
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_firstName_1']")).sendKeys("Harriet");
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_lastName_1']")).clear();
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_lastName_1']")).sendKeys("Wolpin");
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_address1_1']")).clear();
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_address1_1']")).sendKeys("One Old Country Road");
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_city_1']")).clear();
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_city_1']")).sendKeys("CARLE PLACE");
		    Select state = new Select(driverObj.findElement(By.xpath("//select[@data-id='billing_state']")));
		    state.selectByVisibleText("New York");
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_zipCode_1']")).clear();
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_zipCode_1']")).sendKeys("11514");
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_email1_1']")).clear();
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_email1_1']")).sendKeys("cbjarnason@1800flowers.com");
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_phone1_1']")).clear();
		    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_phone1_1']")).sendKeys("5162374674");
	     	}catch(Exception e)
			{
				Reporter.log("Failed Step:  Credit Card TextBox Does not get load.");
			}
		    //driverObj.findElement(By.xpath("//input[@value='Place Your Order']")).click();	
		    //Thread.sleep(2000);
	}
	       /* @AfterClass
		    public void onTestFailure(ITestResult result) {

		        //returns the test which failed
		        result.getMethod().getMethodName();
		        SendMail1 mailreport = new SendMail1();
		        mailreport.sendmail();
		        //SendMail1.sendmail();

		        //create an object of the send mail class and call the method which send the mail and pass the test name which failed as an argument to it.

		    }*/
	        
	       /* @AfterMethod
	        public void writeResult(ITestResult result) throws InterruptedException
	        {
	        	Thread.sleep(13000);
	            try
	            {
	                if(result.getStatus() == ITestResult.SUCCESS)
	                {

	                   System.out.println("No need to send Report");
	                }
	                else if(result.getStatus() == ITestResult.FAILURE)
	                {
	                    SendMail1.sendmail();

	                }
	            }
	            catch(Exception e)
	            {
	                System.out.println("\nLog Message::@AfterMethod: Exception caught");
	                e.printStackTrace();
	            }
	        }*/
	@AfterTest
	public void TearDown()
	{
		driverObj.close();
        driverObj.quit();
}
}