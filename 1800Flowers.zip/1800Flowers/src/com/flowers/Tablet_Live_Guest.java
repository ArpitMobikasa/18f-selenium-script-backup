package com.flowers;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Tablet_Live_Guest {

	WebDriver driverObj=null;
	WebDriverWait wait;
	@Test
	public  void Tablet_Live() throws InterruptedException, ParseException  {
		System.setProperty("webdriver.chrome.driver", "C:\\WORKSPACE\\1800Flowers\\Browser_Drivers\\chromedriver.exe");
		//DesiredCapabilities capabilities = DesiredCapabilities.chrome();
	    //capabilities.setCapability("chrome.switches", Arrays.asList("--incognito"));
	    //driverObj = new ChromeDriver(capabilities);
		
		
		 Map<String, String> mobileEmulation = new HashMap<String, String>();
		    mobileEmulation.put("deviceName", "Apple iPad Mini");
		    Map<String, Object> chromeOptions = new HashMap<String, Object>();
		    chromeOptions.put("mobileEmulation", mobileEmulation);
		    DesiredCapabilities dc = DesiredCapabilities.chrome();
		    dc.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
		   	driverObj = new ChromeDriver(dc);
		
		//driverObj = new ChromeDriver();
		
	    //WebDriver driverObj = new FirefoxDriver();
		
		
		//WebDriver driverObj = new FirefoxDriver(); 
		
		TimeUnit tu=TimeUnit.SECONDS;
		
		driverObj.manage().timeouts().implicitlyWait(150,tu);
		 try{
		driverObj.manage().window().maximize();
		 }catch(Exception e)
			{
				Reporter.log("Failed Step:  Browser does not get load properly");
			}
		driverObj.get("http://t.www.1800flowers.com");
		Calendar cal = Calendar.getInstance();
		//Reporter.log("Test Case Start Time in IST:\n    " +cal.getTime());
	
		/*Date date = new Date();
		 DateFormat timeFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		 timeFormat.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		 String estTime = timeFormat.format(date);
		 date = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss", Locale.ENGLISH).parse(estTime);
		 Reporter.log("Test Case Start Time in EST:    "+ "\n "+date);*/
		
		String tzid = "America/New_York";
	    TimeZone tz = TimeZone.getTimeZone(tzid);

	    long utc = System.currentTimeMillis();
	    Date d = new Date(utc);

	  
	   DateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm a z") ;
	

	    
	   System.err.println(format.format(d)) ;

	   
	    format.setTimeZone(tz);
	    System.err.println(format.format(d)) ;
	    Reporter.log("Test Case Start Time in EDT:    "+ "\n "+format.format(d)) ;
		
	    
	    Thread.sleep(4000);
		//driverObj.navigate().refresh();
		 WebDriverWait wait = new WebDriverWait(driverObj, 150);
		 Thread.sleep(12000);
		 //Thread.sleep(5000);
		 try{
			driverObj.findElement(By.xpath("//li/div[contains(text(),'Birthday')]")).click();
		 }catch(Exception e)
			{
				Reporter.log("Failed Step:  Menu is not Clickable");
			}
			Actions objA = new Actions(driverObj);
			//objA.moveToElement(web).click().build().perform();
			try{
			objA.moveToElement((new WebDriverWait(driverObj, 3)).until(ExpectedConditions.elementToBeClickable(By.xpath("//li/a[contains(text(),'All Birthday Gifts')]")))).click().build().perform();
			//objA.moveToElement((new WebDriverWait(driverObj, 3)).findElement(By.xpath("//ul/li/a[contains(text(),'All Birthday')]"))).click().build().perform();
				}catch(Exception e){
					Reporter.log("Failed Step:  Sub-Menu Does not get load on the Page");
				}
			try{
			Thread.sleep(5000);
			driverObj.findElement(By.xpath("//input[@data-id='gn-zipcode-txt']")).sendKeys("11514");
			}catch(Exception e){
				Reporter.log("Failed Step:  Zipcode Textbox does not get load on the page");
			}
			Thread.sleep(5000);
			/*WebElement element = */driverObj.findElement(By.xpath("//input[@class='secondary_bg row']"));
			//JavascriptExecutor findbutton = (JavascriptExecutor)driverObj; 
	//findbutton.executeScript("arguments[0].click();", element);
			
			driverObj.findElement(By.xpath("//a[contains(text(),'Floral Embrace�')]")).click();
			Thread.sleep(8000);
			try{
			driverObj.findElement(By.xpath("//div[@class='sprites-fw_hdr_search']")).click();
			}catch(Exception e){
				Reporter.log("Failed Step:  Floral Embrace does not get load");
			}
			Thread.sleep(7000);
			try{
			WebElement webElement=driverObj.findElement(By.xpath("//input[@type='search']"));
			webElement.sendKeys("Fields of Europe");
			Thread.sleep(3000);
			//WebElement webElement = driverObj.findElement(By.xpath(""));
			webElement.sendKeys(Keys.ENTER);
				}catch(Exception e){
					Reporter.log("Failed Step:  Search Text box does not get Load on the Page");
				}
			Thread.sleep(6000);
			try{
			driverObj.findElement(By.xpath("//a[@href='//t.www.1800flowers.com/fields-of-europe-90977']")).click();
			//driverObj.findElement(By.xpath("//a[contains(text(),'Fields of Europe�')]")).click();
			}catch(Exception e)
			{
				Reporter.log("Failed Step:  fields-of-europe products does not get load on the page");
			}
			Thread.sleep(9000);
			try{
			driverObj.findElement(By.xpath("//span[contains(text(),'Medium')]")).click();
			}catch(Exception e)
			{
				Reporter.log("Failed Step:  Product is taking time to load on the page");
			}
			Thread.sleep(5000);
			try{
			 driverObj.findElement(By.xpath("//input[@data-id='zipCode']")).sendKeys("11514");
			}catch(Exception e)
			{
				Reporter.log("Failed Step:  Zipcode Textbox does not get load");
			}
			 //driverObj.findElement(By.className("input_overlay")).click();
			 /*WebElement element =*/
			Thread.sleep(3000);
			try{
				driverObj.findElement(By.xpath("//div[@class='input_overlay'][1]")).click();
				//driverObj.findElement(By.xpath("//input[@placeholder='Pick a Delivery Date']")).click();
				//driverObj.findElement(By.xpath("//input[@data-id='deliveryDate']")).click();
				//driverObj.findElement(By.xpath("//a[contains(text(),'Pick a Delivery Date')]")).click();
			/*WebElement deliveryelement=driverObj.findElement(By.xpath("//div[@class='input_overlay']"));
			JavascriptExecutor datebutton = (JavascriptExecutor)driverObj; 
			datebutton.executeScript("arguments[0].click();", deliveryelement);*/
			//driverObj.findElement(By.xpath("//input[@value='Pick a Delivery Date']")).click();
			}catch(Exception e)
			{
				Reporter.log("Failed Step:  No zipcode is entered in the text box as Zipcode textbox does not get load");
			}
			/*Thread.sleep(5000);
			try{
				WebElement Element=driverObj.findElement(By.xpath("//a[@id='shrto_onsite_thumb_715575410_10377290']"));
				Element.click();
			}catch(Exception e)
			{
			Reporter.log("Failed Step: Unexpected Alert appeared on page");
			}*/
			 //driverObj.findElement(By.cssSelector(")
			 
			 //driverObj.findElement(By.xpath("//input[@placeholder='Pick a Delivery Date']")).click();
			 
				//JavascriptExecutor findbutton = (JavascriptExecutor)driverObj; 
				//findbutton.executeScript("arguments[0].click();", element);
			 Date now = new Date();
				DateFormat ord_date = new SimpleDateFormat("dd-MM-yyyy");
				
				cal.setTime(now);
				cal.add(Calendar.DAY_OF_YEAR,22);
				Date randomdate = cal.getTime();
				String t = ord_date.format(randomdate);
				System.out.println(" Random date: "+t);
					
					
				String[] date1 = t.split("-");
				String date2=date1[0];
				int random_date = Integer.parseInt(date2);
				String final1="month1day"+random_date;
				System.out.println("future date: "+final1);
				System.out.println(final1);
				String final2="month2day"+random_date;
				System.out.println("future date: "+final2);
				System.out.println(final2);
				Thread.sleep(3000);
				try{
				//wait.until(ExpectedConditions.elementToBeClickable(By.id(final1))).click();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@id,'"+final1+"') or contains(@id,'"+final2+"')]"))).click();
				}catch(Exception e)
				{
					Reporter.log("Failed Step:  Either Date is not clickable or Product is out of stock");
				}
				
				Thread.sleep(10000);
				
				 JavascriptExecutor jse = (JavascriptExecutor)driverObj;
				 jse.executeScript("window.scrollBy(0,250)", "");
				try{
				//driverObj.findElement(By.xpath("//input[@id='styled_addItemTocartButton' and class=]")).click();
				driverObj.findElement(By.xpath("//input[contains(@id,'styled_addItemTocartButton') and contains(@class,'secondary_bg')]")).click();
				}catch(Exception e)
				{
					Reporter.log("Failed Step:  Either Date is Disable or Date is not clickable");
				}
				
				//Waiting for the Cart Page getting Loaded
				
				Thread.sleep(5000);
				driverObj.findElement(By.xpath("//button[@class='secondary_bg _new_checkout light']")).click();
				//driverObj.findElement(By.xpath("//button[@class='secondary_bg _new_checkout arrow light has_icon']")).click();
			 
				// Thread.sleep(8000);
				 //driverObj.findElement(By.xpath("//input[@data-id='firstName']")).clear();
				 try{
				WebElement focus=driverObj.findElement(By.xpath("//input[@data-id='firstName']"));
				focus.sendKeys("");	
			    focus.sendKeys("test");
				}catch(Exception e)
				{
					Reporter.log("Failed Step:  FirstName texbtox does not get load, Due to this error on the page after submit the button ");
				}
			     
			     driverObj.findElement(By.xpath("//input[@data-id='lastName']")).clear();
			     driverObj.findElement(By.xpath("//input[@data-id='lastName']")).sendKeys("Order");
			     driverObj.findElement(By.xpath("//input[@data-id='QAS_lineone']")).clear();
			     driverObj.findElement(By.xpath("//input[@data-id='QAS_lineone']")).sendKeys("One Old Country Road");

			     driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_phone1_1']")).sendKeys("5162374674");
			     try{
			     driverObj.findElement(By.xpath("//textarea[@data-id='giftMessages_1']")).sendKeys("Test script, please do not fulfill order");
			     }catch(Exception e){
						Reporter.log("Failed Step:  Gift message textbox does not get load ");
				 }
			     Thread.sleep(5000);
			     try{
			     driverObj.findElement(By.xpath("//a[@id='_proceed_to_checkout']")).click();
			     }catch(Exception e)
					{
						Reporter.log("Failed Step:  FirstName textbox does get load.First Name Textbox Field is Mandatory,Kindly fill it ");
					}
			     
			     Thread.sleep(8000);
			     try{
			     //driverObj.findElement(By.xpath("//a[@class='fake_button secondary_bg'][2]")).click();
			     driverObj.findElement(By.xpath("//a[contains(text(),'Address is Correct')]")).click();
			     }catch(Exception e)
					{
						Reporter.log("Failed Step:  FirstName textbox does get load.First Name Textbox Field is Mandatory,Kindly fill it ");
					}
			     Thread.sleep(13000);
			     try{
			     driverObj.findElement(By.xpath("//input[@data-id='account']")).sendKeys("4111111111111111");
			     driverObj.findElement(By.xpath("//input[@data-id='cc_nameoncard']")).sendKeys("Test Order");
			     Select year = new Select(driverObj.findElement(By.xpath("//select[@data-id='expire_month']")));
			        year.selectByVisibleText("12");
			        Select month = new Select(driverObj.findElement(By.xpath("//select[@data-id='expire_year']")));
			        month.selectByVisibleText("2020");
			        Thread.sleep(1000);
			        driverObj.findElement(By.xpath("//input[@data-id='securitycode']")).sendKeys("123");
			        
			        driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_firstName_1']")).clear();
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_firstName_1']")).sendKeys("Harriet");
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_lastName_1']")).clear();
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_lastName_1']")).sendKeys("Wolpin");
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_address1_1']")).clear();
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_address1_1']")).sendKeys("One Old Country Road");
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_city_1']")).clear();
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_city_1']")).sendKeys("CARLE PLACE");
				    Select state = new Select(driverObj.findElement(By.xpath("//select[@data-id='billing_state']")));
				    state.selectByVisibleText("New York");
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_zipCode_1']")).clear();
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_zipCode_1']")).sendKeys("11514");
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_email1_1']")).clear();
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_email1_1']")).sendKeys("cbjarnason@1800flowers.com");
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_phone1_1']")).clear();
				    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_phone1_1']")).sendKeys("5162374674");
			     }catch(Exception e)
					{
						Reporter.log("Failed Step:  Credit Card TextBox Does not get load.");
					}
				    //driverObj.findElement(By.xpath("//input[@value='Place Your Order']")).click();
			     
				    Thread.sleep(6000);
			     
	     	}
	@AfterTest
	public void TearDown()
	{
		driverObj.close();
        driverObj.quit();
}
	
	
}
