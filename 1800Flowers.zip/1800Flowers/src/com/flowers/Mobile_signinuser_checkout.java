package com.flowers;

import java.awt.List;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;
//import java.util.List; 
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class Mobile_signinuser_checkout {


	 public static void main(String[] args) throws InterruptedException {
		  // TODO Auto-generated method stub

		  WebDriver driver;
		  System.setProperty("webdriver.chrome.driver", "Browser_Drivers/chromedriver.exe");
		  
		  ChromeDriver  driverObj=new ChromeDriver();
		  Actions actions = new Actions(driverObj);
		   // WebDriver driverObj=new FirefoxDriver();
		  TimeUnit tu=TimeUnit.SECONDS;
		  WebDriverWait wait = new WebDriverWait(driverObj, 50);
		  driverObj.manage().timeouts().implicitlyWait(50,tu);
		  driverObj.manage().window().maximize();
		  
		  driverObj.get("http://mstage.www.1800flowers.com");
		  
		 //  WebDriverWait wait = new WebDriverWait(driverObj, 50);
		 // WebElement close=driverObj.findElement(By.cssSelector("input.noclose"));
		 
		  // WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("input.noclose")));
		 //  WebElement element = wait.until(ExpectedConditions.elementToBeClickable(close));
		 // element.click();
		  
		        driverObj.findElement(By.className("sprites-fw_search-menu-dark")).click();
		        Thread.sleep(5000);
		        driverObj.findElement(By.xpath("//a[@href='/webapp/wcs/stores/servlet/AjaxLogonForm?storeId=20051&catalogId=13302&langId=-1&MyAccount=Y']")).click();
		        Thread.sleep(5000);
		        driverObj.findElement(By.xpath("//input[@type='email']")).sendKeys("rohit@mobikasa.com");
		        Thread.sleep(2000);
		        driverObj.findElement(By.xpath("//input[@type='password']")).sendKeys("rohit123");
		        //driverObj.findElement(By.cssSelector("button.secondary_bg")).click();
		        Thread.sleep(2000);
		        //WebElement element = driverObj.findElement(By.xpath("//button[@class='secondary_bg']"));
		        WebElement element = driverObj.findElement(By.cssSelector("button.secondary_bg"));
				JavascriptExecutor js = (JavascriptExecutor)driverObj; 
				js.executeScript("arguments[0].click();", element);
		        
		        
		        //driverObj.findElement(By.id("default")).click();
		        Thread.sleep(5000);
		        driverObj.findElement(By.xpath("//div[@class='sprites-fw_search-menu-dark']")).click();
		        Thread.sleep(5000);
		        driverObj.findElement(By.xpath("//a[@id='_link_custom-cruy-0yce']")).click();
		        Thread.sleep(5000);
		        driverObj.findElement(By.name("product2")).click();
		        Thread.sleep(3000);
		        //driverObj.findElement(By.name("Product")).click();
		        driverObj.executeScript("window.scrollBy(0,200)", "");
                Thread.sleep(3000);
		        driverObj.findElement(By.xpath("//input[@type='tel']")).sendKeys("11001");
		       // Select dropdown = new Select(driverObj.findElement(By.className("check_val required icon-drop_down has_value")));
		      //  dropdown.selectByValue("Business");
		        WebElement element1 = driverObj.findElement(By.xpath("//div[@class='input_overlay']"));
		       actions.moveToElement(element1).click().perform();
	             
		       Date now = new Date();
				DateFormat ord_date = new SimpleDateFormat("dd-MM-yyyy");
				Calendar cal = Calendar.getInstance();
				cal.setTime(now);
				cal.add(Calendar.DAY_OF_YEAR,15);
				Date randomdate = cal.getTime();
				String t = ord_date.format(randomdate);
				System.out.println("21 days later: "+t);
					
			
				String[] date1 = t.split("-");
				String date=date1[0];
				int random_date = Integer.parseInt(date);
				String final1="month2day"+random_date;
				System.out.println("future date: "+final1);
				System.out.println(final1);
				Thread.sleep(3000);
				wait.until(ExpectedConditions.elementToBeClickable(By.id(final1))).click();
				 
				Thread.sleep(5000);
		       
		       //wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='month2day1']"))).click();
			    Thread.sleep(5000);
			    driverObj.executeScript("window.scrollBy(0,200)", "");
			    Thread.sleep(1000);
			    
			    WebElement element_Buy= driverObj.findElement(By.xpath("//button[@class='secondary_bg _new_checkout arrow light has_icon']"));
			    JavascriptExecutor executor = (JavascriptExecutor)driverObj;
			    executor.executeScript("arguments[0].click();", element_Buy);
			    driverObj.findElement(By.xpath("//input[@data-id='firstName']")).sendKeys("Mobikasa");
			    driverObj.findElement(By.xpath("//input[@data-id='lastName']")).sendKeys("tester");
			    driverObj.findElement(By.xpath("//input[@data-id='QAS_lineone']")).sendKeys("D-45");
			    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_phone1_1']")).sendKeys("0000000000");
			    driverObj.executeScript("window.scrollBy(0,400)", "");
			   // driverObj.findElement(By.xpath("//input[@data-id='billingAddress']")).click();
			    driverObj.findElement(By.xpath("//a[@id='_proceed_to_checkout']")).click();
			    Thread.sleep(5000);
			    driverObj.findElement(By.xpath("//a[@class='fake_button secondary_bg small']")).click();
			    Thread.sleep(5000);
			    driverObj.findElement(By.xpath("//input[@data-id='account']")).sendKeys("5454545454545454");
			    driverObj.findElement(By.xpath("//input[@data-id='cc_nameoncard']")).sendKeys("test test");
			    driverObj.executeScript("window.scrollBy(0,400)", "");
			    Select dropdown_month = new Select(driverObj.findElement(By.xpath("//select[@data-id='expire_month']")));
			    dropdown_month.selectByValue("01");
			    Select dropdown_year = new Select(driverObj.findElement(By.xpath("//select[@data-id='expire_year']")));
			    dropdown_year.selectByValue("2016");
			    driverObj.findElement(By.xpath("//input[@data-id='securitycode']")).sendKeys("111");
			    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_address1_1']")).sendKeys("D-45");
			    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_city_1']")).sendKeys("NY");
			    Select dropdown_State = new Select(driverObj.findElement(By.xpath("//select[@data-id='billing_state']")));
			    dropdown_State.selectByValue("NY");
			    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_zipCode_1']")).sendKeys("11001");
			    driverObj.findElement(By.xpath("//input[@data-id='WC_ShoppingCartAddressEntryForm_FormInput_phone1_1']")).sendKeys("0000000000");
			    driverObj.executeScript("window.scrollBy(0,200)", "");
			    driverObj.findElement(By.xpath("//input[@class='secondary_bg']")).click();
		 }

		
	}
