package com.flowers;
import java.util.*;
import java.io.File;
import java.io.IOException;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import org.testng.annotations.Test;

public class SendMail1 {
	
	
	public static void sendmail() throws IOException
	{
		final String username = "anuj.mobikasa@gmail.com";
	    final String password = "mobikasa";

	    Properties props = new Properties();
	    props.put("mail.smtp.auth", true);
	    props.put("mail.smtp.starttls.enable", true);
	    props.put("mail.smtp.host", "smtp.gmail.com");
	    props.put("mail.smtp.port", "587");

	    Session session = Session.getInstance(props,new javax.mail.Authenticator() {
	                protected PasswordAuthentication getPasswordAuthentication() {
	                    return new PasswordAuthentication(username, password);
	                }
	            });

	    try {

	        Message message = new MimeMessage(session);
	        
	        message.setFrom(new InternetAddress("anuj@mobikasa.com"));
	        
	       // message.setRecipients(Message.RecipientType.TO,
		     // InternetAddress.parse("rachit@mobikasa.com"));
		       message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("anuj@mobikasa.com"));
		     //message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("cbjarnason@1800flowers.com"));
		     // message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("mailrohit007@gmail.com"));
	        message.setRecipients(Message.RecipientType.CC,InternetAddress.parse("anujkumarjoshi.ignited@gmail.com"));
	        

	        
	       //message.setRecipients(Message.RecipientType.CC,
	             // InternetAddress.parse("rohit@mobikasa.com"));
	        
	      
	        
	        	       
	        //message.setSubject("Automation Execution Report :- for ca site");
	        message.setSubject("18F .CA Production/Staging Failure");
	      /*  MimeBodyPart messageBodyPart = new MimeBodyPart();

	        Multipart multipart = new MimeMultipart();	

	        messageBodyPart = new MimeBodyPart();
	        //String file = "D://test-output/index.html";
	        String file="test-output/emailable-report.html";
	        String fileName = "emailable-report.html";
	        DataSource source = new FileDataSource(file);
	        messageBodyPart.setDataHandler(new DataHandler(source));
	        messageBodyPart.setFileName(fileName);
	        multipart.addBodyPart(messageBodyPart);
	       // messageBodyPart.setText("Kindly find the automation execution report in attachment.");
	        message.setContent(multipart);
	       
	        System.out.println("Sending");

	        Transport.send(message);

	        System.out.println("Done");     */
			
			
			Multipart multipart = new MimeMultipart();
		        
		        MimeBodyPart textPart = new MimeBodyPart();
		        String textContent = "Hi,\n\nPlease find the attached failed report. \n\nRegards,\nAnuj";
		        textPart.setText(textContent);
		        multipart.addBodyPart(textPart);
		        
		        MimeBodyPart attachementPart = new MimeBodyPart();
		        attachementPart.attachFile(new File("test-output/emailable-report.html"));
		        multipart.addBodyPart(attachementPart);
		        System.out.println("Sending Failed report");
		        message.setContent(multipart);
		        Transport.send(message);
		        System.out.println("---Done---");
			

	    } catch (MessagingException e) {
	        e.printStackTrace();
	    }
	  }

}
