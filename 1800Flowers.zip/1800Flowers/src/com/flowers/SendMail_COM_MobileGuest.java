
package com.flowers;
import java.io.File;
import java.io.IOException;
import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import org.apache.commons.io.FileUtils;
import org.testng.TestNG;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

public class SendMail_COM_MobileGuest {
	
	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		System.out.println("hi");
		try{
		FileUtils.forceDelete(new File("C:\\WORKSPACE\\1800Flowers\\test-output"));
		}catch(Exception e){
			e.printStackTrace();
		}
		TestNG testng = new TestNG();
		List<String> suites = Lists.newArrayList();
		suites.add("C:\\WORKSPACE\\1800Flowers\\xmlfiles\\testng_mobile_guest.xml");
		testng.setTestSuites(suites);
		try{
			testng.run();
		}catch(Exception e){
			e.printStackTrace();
		}
	//Thread.sleep(8000);
		System.out.println("Start Executing Sendmail Function");
		//sendmail();
		if(new File("test-output\\testng-failed.xml").exists()){
		sendmail();
		}
		else
			System.out.println("Test Case Passed: No need to send mail");
		
	}
	public static void sendmail() throws IOException
	{
	
        
	      
			final String username = "anuj@mobikasa.com";
		    final String password = "mobikasa";

		    Properties props = new Properties();
		    props.put("mail.smtp.auth", true);
		    props.put("mail.smtp.starttls.enable", true);
		    props.put("mail.smtp.host", "smtp.gmail.com");
		    props.put("mail.smtp.port", "587");

		    Session session = Session.getInstance(props,new javax.mail.Authenticator() {
		                protected PasswordAuthentication getPasswordAuthentication() {
		                    return new PasswordAuthentication(username, password);
		                }
		            });

		    try {
		    	//Transport transport = session.getTransport("smtp"); 
		        Message message = new MimeMessage(session);
		        message.setFrom(new InternetAddress("anuj@mobikasa.com"));
		       
		     
		   // message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("mobiledev@1800flowers.com"));
		    //message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("anuj.mobikasa@gmail.com"));
		        message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("anujkumarjoshi.ignited@gmail.com"));  
		  //message.setRecipients(Message.RecipientType.CC,InternetAddress.parse("rachit@mobikasa.com,shivangi@mobikasa.com"));
		      
		        message.setSubject("18F Mobile Web: Staging Failure");
		        //message.setText("Hi,\n\nPlease find attached failed report. \n\nRegards,\nAnuj");
		        
		        
		        
                Multipart multipart = new MimeMultipart();
		        
		        MimeBodyPart textPart = new MimeBodyPart();
		        String textContent = "Hi,\n\nPlease find the attached failed report. \n\nRegards,\nAnuj";
		        textPart.setText(textContent);
		        multipart.addBodyPart(textPart);
		        
		        MimeBodyPart attachementPart = new MimeBodyPart();
		        attachementPart.attachFile(new File("test-output/emailable-report.html"));
		        multipart.addBodyPart(attachementPart);
		        System.out.println("Sending Failed report");
		        message.setContent(multipart);
		        Transport.send(message);
		        System.out.println("---Done---");
		    
		        

		    } catch (MessagingException e) {
		        e.printStackTrace();
		    }
	  }

}
