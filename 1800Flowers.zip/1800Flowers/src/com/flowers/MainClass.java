package com.flowers;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import javax.activation.*;
import javax.mail.*;
import javax.mail.internet.*;

import org.apache.commons.io.FileUtils;
import org.testng.TestNG;
import org.testng.collections.Lists;

public class MainClass  {



	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		System.out.println("hi");
		try{
		FileUtils.forceDelete(new File("C:\\WORKSPACE\\1800Flowers\\test-output"));
		}catch(Exception e){
			e.printStackTrace();
		}
		TestNG testng = new TestNG();
		List<String> suites = Lists.newArrayList();
		suites.add("C:\\WORKSPACE\\1800Flowers\\testng_mobile.xml");
		testng.setTestSuites(suites);
		try{
			testng.run();
		}catch(Exception e){
			e.printStackTrace();
		}
	//Thread.sleep(8000);
		System.out.println("Start Executing Sendmail Function");
		//sendmail();
		if(new File("test-output\\testng-failed.xml").exists()){
		sendmail();
		}
		else
			System.out.println("Test Case Passed: No need to send mail");
		
	}
	public static void sendmail() throws IOException
	{
	
        
	      
			final String username = "anuj@mobikasa.com";
		    final String password = "Anuj@262193";

		    Properties props = new Properties();
		    props.put("mail.smtp.auth", true);
		    props.put("mail.smtp.starttls.enable", true);
		    props.put("mail.smtp.host", "smtp.gmail.com");
		    props.put("mail.smtp.port", "587");

		    Session session = Session.getInstance(props,new javax.mail.Authenticator() {
		                protected PasswordAuthentication getPasswordAuthentication() {
		                    return new PasswordAuthentication(username, password);
		                }
		            });

		    try {
		    	//Transport transport = session.getTransport("smtp"); 
		        Message message = new MimeMessage(session);
		        message.setFrom(new InternetAddress("anuj@mobikasa.com"));
		       
		     //   message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("flws-issues@moovweb.com"));
		   // message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("mobiledev@1800flowers.com"));
		    message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("anuj.mobikasa@gmail.com"));
		    //  message.setRecipients(Message.RecipientType.TO,InternetAddress.parse("mailrohit007@gmail.com"));
		        //message.setRecipients(Message.RecipientType.TO,
		        //       InternetAddress.parse("mobiledev@1800flowers.com"));
		    //message.setRecipients(Message.RecipientType.CC,InternetAddress.parse("rachit@mobikasa.com,anujkumarjoshi.ignited@gmail.com,shivangishukla2712@gmail.com"));
		    message.setRecipients(Message.RecipientType.CC,InternetAddress.parse("rachit@mobikasa.com,shivangishukla2712@gmail.com"));
		      //  message.setRecipients(Message.RecipientType.CC,InternetAddress.parse("Danielle@sooryen.com,mobiledev@1800flowers.com,rachit@mobikasa.com,mailrohit1@gmail.com"));
		        //message.setRecipients(Message.RecipientType.CC,
		          //      InternetAddress.parse("shruti@mobikasa.com"));
		        //message.setRecipients(Message.RecipientType.CC,
		          //      InternetAddress.parse("mailrohit1@gmail.com"));
		        //message.setSubject("Automation Execution Report :- for Mobile site");
		        message.setSubject("18F Mobile App: Production/Staging Failure");
		        message.setText("Hi,\n\nPlease find attached failed report. \n\nRegards,\nAnuj");
		        //message.setContent("Hi,\n\nPlease find the attached failed report. \n\nRegards,\nRohit","text/html; charset=utf-8");
		        //System.out.println(message);
		        
		        
		        
		        
		        
		        
		       /* MimeBodyPart messageBodyPart = new MimeBodyPart();

		        Multipart multipart = new MimeMultipart();

		        messageBodyPart = new MimeBodyPart();
		        //String file = "D://test-output/index.html";
		        String file="test-output/emailable-report.html";
		        System.out.println(file);
		        String fileName = "emailable-report.html";
		        DataSource source = new FileDataSource(file);
		        messageBodyPart.setDataHandler(new DataHandler(source));
		        messageBodyPart.setFileName(fileName);
		        multipart.addBodyPart(messageBodyPart);

		        message.setContent(multipart);
		        //message.setText("Hi,\n\nPlease find the attached failed report. \n\nRegards,\nRohit" );

		        System.out.println("Sending Failed report");

		        Transport.send(message);

		        System.out.println("Done");*/
		        
		        
  Multipart multipart = new MimeMultipart();
		        
		        MimeBodyPart textPart = new MimeBodyPart();
		        String textContent = "Hi,\n\nPlease find the attached failed report. \n\nRegards,\nAnuj";
		        textPart.setText(textContent);
		        multipart.addBodyPart(textPart);
		        
		        MimeBodyPart attachementPart = new MimeBodyPart();
		        attachementPart.attachFile(new File("test-output/emailable-report.html"));
		        multipart.addBodyPart(attachementPart);
		        System.out.println("Sending Failed report");
		        message.setContent(multipart);
		        Transport.send(message);
		        System.out.println("---Done---");
		    
		        

		    } catch (MessagingException e) {
		        e.printStackTrace();
		    }
	  }
}
