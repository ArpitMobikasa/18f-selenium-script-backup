
package com.flowers;
import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import org.testng.annotations.Test;

public class sendmail_mobile {
	
	@Test
	public static void sendmail()
	{
		final String username = "shivangi@mobikasa.com";
	    final String password = "Sh!v!2712";

	    Properties props = new Properties();
	    props.put("mail.smtp.auth", true);
	    props.put("mail.smtp.starttls.enable", true);
	    props.put("mail.smtp.host", "smtp.gmail.com");
	    props.put("mail.smtp.port", "587");

	    Session session = Session.getInstance(props,
	            new javax.mail.Authenticator() {
	                protected PasswordAuthentication getPasswordAuthentication() {
	                    return new PasswordAuthentication(username, password);
	                }
	            });

	    try {

	        Message message = new MimeMessage(session);
	        
	        message.setFrom(new InternetAddress("shivangi@mobikasa.com"));
	        
	          
	        message.setRecipients(Message.RecipientType.CC,
	                InternetAddress.parse("anuj@mobikasa.com,shivangishukla2712@gmail.com"));
	        
	        message.setRecipients(Message.RecipientType.TO,
	            InternetAddress.parse("mobiledev@1800flowers.com"));
	        
	       message.setRecipients(Message.RecipientType.CC,
	              InternetAddress.parse("rachit@mobikasa.com"));
	        
	        /*message.setRecipients(Message.RecipientType.TO,
	                InternetAddress.parse("rachit@mobikasa.com"));*/
	        
	      //  message.setRecipients(Message.RecipientType.TO,
		         //      InternetAddress.parse("cbjarnason@1800flowers.com"));
	        	       	       
	        message.setSubject("Automation Execution Report :- for Mobile site");
	       
	        message.setText("PFA"); 
	        MimeBodyPart messageBodyPart = new MimeBodyPart();

	        Multipart multipart = new MimeMultipart();

	        messageBodyPart = new MimeBodyPart();
	        //String file = "D://test-output/index.html";
	        String file="test-output/emailable-report.html";
	        String fileName = "emailable-report.html";
	        DataSource source = new FileDataSource(file);
	        messageBodyPart.setDataHandler(new DataHandler(source));
	        messageBodyPart.setFileName(fileName);
	        multipart.addBodyPart(messageBodyPart);
	       // messageBodyPart.setText("Kindly find the automation execution report in attachment.");
	        message.setContent(multipart);
	       
	        System.out.println("Sending");

	        Transport.send(message);

	        System.out.println("Done");

	    } catch (MessagingException e) {
	        e.printStackTrace();
	    }
	  }

}
