package com.testing;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



public class fblogin {

	//ChromeDriver  driverObj=new ChromeDriver();
	ChromeDriver driverObj;
	WebDriverWait wait;
	
	@Test
	public void fb_login() throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "Browser_Drivers/chromedriver.exe");
		
		driverObj=new ChromeDriver();
		
	  // WebDriver driverObj=new FirefoxDriver();
		TimeUnit tu=TimeUnit.SECONDS;
		
		driverObj.manage().timeouts().implicitlyWait(50,tu);
		driverObj.manage().window().maximize();
		
	//	driverObj.get("http://www.facebook.com");
		
		 WebDriverWait wait = new WebDriverWait(driverObj, 50);
		//driverObj.findElement(By.xpath("//input[@type='email']")).sendKeys("emailadd");
		//driverObj.findElement(By.xpath("//input[@type='password']")).sendKeys("password");
		//driverObj.findElement(By.xpath("//input[@value='Log In']")).click();
		 driverObj.get("https://www.flipkart.com");
		 Thread.sleep(2000);
		 driverObj.findElement(By.linkText("Login")).click();
		 driverObj.findElementByXPath("//input[@class='fk-input login-form-input user-email']").sendKeys("test");
		 driverObj.findElementByXPath("//input[@type='password']").sendKeys("test");
		 driverObj.findElement(By.xpath("//input[@class='submit-btn login-btn btn']")).click(); 
       
     	}
	
	
	
	@AfterClass
	public void TearDown()
	{
		driverObj.close();
      driverObj.quit();
      
		
	}
	
}
