package com.testing;
import java.awt.List;
import java.util.concurrent.TimeUnit;
//import java.util.List; 
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.WebElement; 


public class Checkout_Product {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "Browser_Drivers/chromedriver.exe");
		ChromeDriver  driverObj=new ChromeDriver();
		TimeUnit tu=TimeUnit.SECONDS;
		
		driverObj.manage().timeouts().implicitlyWait(20,tu);
		driverObj.manage().window().maximize();
		
		driverObj.get("http://www.1800flowers.ca/fields-of-europe-summer/?occasionId=22");
		
		//Thread.sleep(2000);
		//Actions action = new Actions(driverObj);
		//action.sendKeys(Keys.ESCAPE).build().perform();
		
		//driverObj.findElement(By.linkText("No thanks, I'll pay full price.")).click();
		//driverObj.findElement(By.xpath("//[contains(text(), 'No thanks, I'll pay full price.')]")).click();
		//driverObj.findElementByClassName("noclose").click();
		
		//Alert alert = driverObj.switchTo().alert();
		//alert.dismiss();
		
		//WebElement element =  driverObj.findElement(By.xpath("//[contains(text(), 'No thanks, I'll pay full price.')]"));
	    //((JavascriptExecutor) driverObj).executeScript("arguments[0].disabled = false", element);
	    //Thread.sleep(2000);
	    //element.click();
		
		//driverObj.findElement(By.xpath("//input[@value='button']")).click();
		
		//driverObj.findElement(By.className("close")).click();
		Actions action = new Actions(driverObj);
		action.sendKeys(Keys.ESCAPE).build().perform();
		//driverObj.findElement(By.xpath("//img[@title ='Fields of Europe']")).click();
		action.sendKeys(Keys.ESCAPE).build().perform();
		//Actions action = new Actions(driverObj);
		//action.sendKeys(Keys.ESCAPE).build().perform();
		//driverObj.findElement(By.xpath("//img[@src ='/productres/xFields_of_Europe_Summer_20152205144337.jpg.pagespeed.ic.uhM4khLwDv.jpg']")).click();
		//String URL = driverObj.getCurrentUrl();
		//Assert.assertEquals(URL, "http://www.1800flowers.ca/fields-of-europe-summer" );
		//driverObj.findElement(By.name("postalcode")).sendKeys("B3P2L5");
		driverObj.findElement(By.xpath("//input[@id='postalcode']")).sendKeys("B3P2L5");
		Thread.sleep(5000);
		driverObj.findElement(By.id("deliverybutton")).click();
		//action.sendKeys(Keys.ESCAPE).build().perform();
		
		//driverObj.findElement(By.id("//div[2]/ul[3]/li[1]/i")).click();
        //driverObj.findElement(By.id("D20-08-2015")).click();
        //driverObj.findElement(By.xpath("//a[@id='D20-08-2015']")).click();
       // driverObj.findElement(By.className(" btn-lg")).click();
        
        
        //driverObj.switchTo().frame(0);  
        //driverObj.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);  
        //Click on textbox so that datepicker will come  
        //driver.findElement(By.id("datepicker")).click();  
        //driverObj.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);  
        //Click on next so that we will be in next month  
        //driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[2]/span")).click();  
          
        /*DatePicker is a table.So navigate to each cell   
         * If a particular cell matches value 13 then select it  
         */  
        
        //driverObj.findElement(By.xpath("//a[@id='D20-08-2015']")).click();
        
        /*
        driverObj.findElement(By.id("table/tbody/tr[3]/td[5]/a")).click();
        
        
        
        WebElement dateWidget = driverObj.findElement(By.id("month-August2015"));  
        List<WebElement> rows=dateWidget.findElements(By.tagName("tr"));  
        List<WebElement> columns=dateWidget.findElements(By.tagName("td"));  
          
        for (WebElement cell: columns){  
         //Select 13th Date   
         if (cell.getText().equals("28")){  
         cell.findElement(By.linkText("28")).click();  
         break;  
         */
         Thread.sleep(20000);
  	   
  	   //driverObj.findElement(By.xpath("//*[@id='D28-08-2015']/span[1]")).click();
         driverObj.findElement(By.xpath("//a[@id='D31-08-2015']")).click();
         
  	   
  	   Thread.sleep(20000);
       
		
         }  
	
}
