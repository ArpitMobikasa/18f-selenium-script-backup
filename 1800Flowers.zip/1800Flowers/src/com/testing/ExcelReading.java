package com.testing;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReading {

	public static String[][] fn_TestData_2DArr(String Path, String SheetName) throws IOException{
		Workbook wbObj=fn_GetWorkbook(Path);
		MissingCellPolicy MCP=Row.CREATE_NULL_AS_BLANK;
		Sheet wsheet=wbObj.getSheet(SheetName);
		 int rowcnt=wsheet.getLastRowNum();
		int colmcnt=wsheet.getRow(0).getLastCellNum();
		
		   String[][] Arr_2D=new String[rowcnt][colmcnt];
		int cntr=0;
			for(int i=1; i<=rowcnt-1; i++){
				Row rowObj=wsheet.getRow(i);
					    if(rowObj!=null){
						    	
								int cellcnt=rowObj.getLastCellNum();////count will be actual count
								String [] Row_1Darr=new String[cellcnt];
									for(int j=0; j<=cellcnt-1;j++)
									{
										
										Cell cellObj=rowObj.getCell(j, MCP);
										int celltypeindex=cellObj.getCellType();
										String data=null;
											   if(celltypeindex==1){
												    data=cellObj.getStringCellValue();
											   }else if(celltypeindex==0){
												    Double data_dbl=cellObj.getNumericCellValue();
												    Integer data_int=data_dbl.intValue();
												    data=data_int.toString();
											   }
											
											   Arr_2D[i][j]=data;
											     
									}
								
								
					    }
						
			}
			return Arr_2D;
	}	

	

	public static Workbook fn_GetWorkbook(String xlPath) throws IOException{
		FileInputStream FIS=new FileInputStream(xlPath);
		String[] arr=xlPath.split("\\.");
		String ext=arr[1];
		Workbook wbookObj=null;
		if(ext.equalsIgnoreCase("xls")){
			  wbookObj =new HSSFWorkbook(FIS);
		}else if (ext.equalsIgnoreCase("xlsx")){
			 wbookObj =new XSSFWorkbook(FIS);
		}
		return wbookObj;
	}
	
}
