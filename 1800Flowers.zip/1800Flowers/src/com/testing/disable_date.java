package com.testing;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import net.sf.cglib.core.Predicate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

//import com.thoughtworks.selenium.Wait;

//import com.thoughtworks.selenium.Wait;

public class disable_date {
	
	ChromeDriver driverObj;
	//WebDriverWait wait;
	
	@Test
	public void fn_checkout_ca() throws InterruptedException
	{
		//WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:\\WORKSPACE\\1800Flowers\\Browser_Drivers/chromedriver.exe");
		
		driverObj=new ChromeDriver();
		
	  // WebDriver driverObj=new FirefoxDriver();
		TimeUnit tu=TimeUnit.SECONDS;
		
		driverObj.manage().timeouts().implicitlyWait(50,tu);
		driverObj.manage().window().maximize();
		
		driverObj.get("http://qa.1800flowers.ca");
		Thread.sleep(5000);
		
		
		WebDriverWait wait = new WebDriverWait(driverObj, 50);
		WebElement close=driverObj.findElement(By.cssSelector("input.noclose"));
	
		// WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("input.noclose")));
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(close));
		element.click();
		
		

		Thread.sleep(5000);
		WebElement web = driverObj.findElement(By.xpath("//a/span[contains(text(),'Birthday')]"));
		Actions objA = new Actions(driverObj);
		objA.moveToElement(web).click().build().perform();
		try{
		objA.moveToElement((new WebDriverWait(driverObj, 3)).until(ExpectedConditions.elementToBeClickable(By.xpath("//ul/li/a[contains(text(),'All Birthday')]")))).click().build().perform();
		//objA.moveToElement((new WebDriverWait(driverObj, 3)).findElement(By.xpath("//ul/li/a[contains(text(),'All Birthday')]"))).click().build().perform();
		}catch(Exception e){}
		
		driverObj.findElement(By.xpath("html/body/div[3]/div[1]/div[1]/div/div/div[8]/div[2]/form/input")).sendKeys("91127");
		
		driverObj.findElement(By.xpath("html/body/div[3]/div[1]/div[1]/div/div/div[8]/div[2]/form/button")).click();
		
		Thread.sleep(3000);
		driverObj.findElement(By.xpath("//a[contains(text(),'Fields of Europe Summer')]")).click();
		
		Thread.sleep(3000);
        driverObj.findElement(By.xpath("//input[@id='postalcode']")).sendKeys("B3P2L5");
       
        WebElement element1 = driverObj.findElement(By.xpath("//button[@id='deliverybutton']"));
        Actions actions = new Actions(driverObj);
        actions.moveToElement(element1).click().perform();
    
		Date now = new Date();
		DateFormat ord_date = new SimpleDateFormat("dd-MM-yyyy");
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_YEAR,21);
		Date randomdate = cal.getTime();
		String t = ord_date.format(randomdate);
		System.out.println("Random date: "+t);
		String final1='D'+t;
		//String[] date1 = t.split("-");
		//String date=date1[0];
		System.out.println("future date: "+final1);
		System.out.println(final1);
		Thread.sleep(3000);
		WebElement disable=driverObj.findElement(By.xpath("//div[@class='day-number']"));
		WebElement enable=driverObj.findElement(By.xpath("//a*[@class='daypick']"));
		//if(web.equals(driverObj.findElement(By.xpath("//div[@class='day-number']"))))
		
			if(web.equals(disable))
		{
				cal.add(Calendar.DAY_OF_YEAR,22);
				Date randomdate1 = cal.getTime();
				String t1 = ord_date.format(randomdate1);
				System.out.println("Random date: "+t1);
				String final11='D'+t1;
				String[] date11 = t1.split("-");
				String date2=date11[0];	
		}
		wait.until(ExpectedConditions.elementToBeClickable(By.id(final1))).click();
		  
		//Select location = new Select(driverObj.findElement(By.xpath("//select[@id='seladdon22_354860']")));
		//Select location = new Select(driverObj.findElement(By.xpath("html/body/div[2]/div[1]/form/div/div/div[3]/div[7]/select")));
       //location.selectByVisibleText("1-C$9.99");
        //location.selectByIndex(0);
        Thread.sleep(8000);
        driverObj.findElement(By.xpath("//button[@class='btn btn-success btn-lg']")).click();
        Thread.sleep(5000);
        //driverObj.findElement(By.id("firstcheckout" ));
        driverObj.findElement(By.xpath("//button[@id='firstcheckout']")).click();
        Thread.sleep(4000);
        //driverObj.findElement(By.xpath("//input[@class='enclose_card']")).click();
        
        //Select occasion = new Select(driverObj.findElement(By.id("occasion_id357267")));
        Select occasion = new Select(driverObj.findElement(By.xpath("//select[@class='form-control ocassion_hide']")));
        occasion.selectByVisibleText("Birthday");
        driverObj.findElement(By.xpath("//textarea[@class='form-control cardmsg']")).sendKeys("Test script, please do not fulfill order");
        
        driverObj.findElement(By.xpath("//button[contains(text(),'Next')]")).click();
        //driverObj.findElement(By.xpath("//button[@class='btn btn-success btn-lg']")).click();
        Thread.sleep(3000);
        
        driverObj.findElement(By.xpath("//input[@type='text']")).sendKeys("rohitkumar");
        driverObj.findElement(By.xpath("//input[@type='password']")).sendKeys("rohitkumar");
       // driverObj.findElement(By.xpath("//input[@class='form-control nwfc']")).sendKeys("canadadev@1800flowers.com");
        driverObj.findElement(By.xpath("//input[@value='Sign-in']")).click();
        Thread.sleep(3000);
        //driverObj.findElement(By.xpath("//input[@type='checkbox']")).click();
        
       // driverObj.findElement(By.id("firstname1")).clear();
        driverObj.findElement(By.id("firstname1")).sendKeys("cardtest");
        driverObj.findElement(By.id("lastname1")).clear();
        driverObj.findElement(By.id("lastname1")).sendKeys("test");
        Select location1 = new Select(driverObj.findElement(By.id("location_type1")));
        location1.selectByVisibleText("Residence");
        driverObj.findElement(By.id("address11")).clear();
        driverObj.findElement(By.id("address11")).sendKeys("40 Bay St");
        driverObj.findElement(By.id("postalcode1")).clear();
        driverObj.findElement(By.id("postalcode1")).sendKeys("M5J 2X2");
        driverObj.findElement(By.id("city1")).clear();
        driverObj.findElement(By.id("city1")).sendKeys("St Johns");
        Select province = new Select(driverObj.findElement(By.id("province1")));
        province.selectByVisibleText("Ontario");
        driverObj.findElement(By.id("dayphone1")).clear();
        driverObj.findElement(By.id("dayphone1")).sendKeys("5162374861");
        //driverObj.findElement(By.xpath("//button[@class='btn btn-success btn-lg']")).click();
        driverObj.findElement(By.xpath("//button[contains(text(),'Next')]")).click();
        Thread.sleep(3000);
        
	     driverObj.findElement(By.xpath("//input[@id='cardnumber']")).sendKeys("4111111111111111");
	     //driverObj.findElement(By.xpath("//input[@data-id='cc_nameoncard']")).sendKeys("cardtest");
	     Select year = new Select(driverObj.findElement(By.xpath("//select[@id='expiry_month']")));
	     year.selectByVisibleText("12");
	     Select month = new Select(driverObj.findElement(By.xpath("//select[@id='expiry_year']")));
	     month.selectByVisibleText("2025");
	     driverObj.findElement(By.xpath("//input[@name='cvv']")).sendKeys("111");
        
        driverObj.findElement(By.id("firstname")).clear();
        driverObj.findElement(By.id("firstname")).sendKeys("cardtest");
        driverObj.findElement(By.id("lastname")).clear();
        driverObj.findElement(By.id("lastname")).sendKeys("test");
        driverObj.findElement(By.id("address1")).clear();
        driverObj.findElement(By.id("address1")).sendKeys("40 Bay St");
        driverObj.findElement(By.id("postalcode")).clear();
        driverObj.findElement(By.id("postalcode")).sendKeys("M5J 2X2");
        driverObj.findElement(By.id("city")).clear();
        driverObj.findElement(By.id("city")).sendKeys("St Johns");
        Select province1 = new Select(driverObj.findElement(By.id("province")));
        province1.selectByVisibleText("Ontario");
        Thread.sleep(5000);
        driverObj.findElement(By.id("dayphone")).clear();
        driverObj.findElement(By.id("dayphone")).sendKeys("5162374861");
        //driverObj.findElement(By.id("submit_order")).click();
       // Assert.assertTrue(true);
        //Reporter.log("test case passed");
        
       	}
	
	/*@AfterMethod
    public void writeResult(ITestResult result)
    {
        try
        {
            if(result.getStatus() == ITestResult.SUCCESS)
            {

               System.out.println("No need to send Report");
            }
            else if(result.getStatus() == ITestResult.FAILURE)
            {
            	SendMail1.sendmail();

            }
        }
        catch(Exception e)
        {
            System.out.println("\nLog Message::@AfterMethod: Exception caught");
            e.printStackTrace();
        }
    }*/
	
	
	@AfterTest
	public void TearDown()
	{
		driverObj.close();
        driverObj.quit();
      
		
	}

}
