package com.testing;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;


import org.apache.james.mime4j.field.datetime.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class random_calendar {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "Browser_Drivers/chromedriver.exe");
		
		ChromeDriver  driverObj=new ChromeDriver();
		
	  // WebDriver driverObj=new FirefoxDriver();
		TimeUnit tu=TimeUnit.SECONDS;
		
		driverObj.manage().timeouts().implicitlyWait(50,tu);
		driverObj.manage().window().maximize();
		
		driverObj.get("http://www.1800flowers.ca/fields-of-europe-summer/?occasionId=22");
		
		 WebDriverWait wait = new WebDriverWait(driverObj, 50);
		WebElement close=driverObj.findElement(By.cssSelector("input.noclose"));
	
		// WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("input.noclose")));
		 WebElement element = wait.until(ExpectedConditions.elementToBeClickable(close));
		element.click();
		
        driverObj.findElement(By.xpath("//input[@id='postalcode']")).sendKeys("B3P2L5");
       
        
        WebElement element1 = driverObj.findElement(By.xpath("//button[@id='deliverybutton']"));

        Actions actions = new Actions(driverObj);

        actions.moveToElement(element1).click().perform();
             
        //wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='D31-08-2015']"))).click();
        
        
       /* Date today = new Date();
        Date minusThree = new Date();
        Calendar now = Calendar.getInstance();
        now.setTime(today);
        Calendar before = Calendar.getInstance();
        before.setTime(minusThree);
        before.add(Calendar.DAY_OF_YEAR, 5);
        int monthNow = now.get(Calendar.MONTH);
        int monthBefore = before.get(Calendar.MONTH);

        if (monthBefore < monthNow){
          // click previous month in the calendar tooltip on page
        }
        //WebElement dateToSelect = driverObj.findElement(By.xpath("//span[text()='"+threeDaysBefore()+"']"));
        WebElement dateToSelect = driverObj.findElement(By.xpath("//a[@class='daypick2'][threeDaysBefore()]"));
        
        //WebElement dateToSelect =wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='datepick2'][threeDaysBefore()]")));
        
        dateToSelect.click();
	
        
        	   }
	
	public static String threeDaysBefore(){
        String threeDaysBefore = "";
        Date date = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);

        cal.add(Calendar.DAY_OF_YEAR,5);
        Date before = cal.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("dd");
        threeDaysBefore = formatter.format(before);
        return threeDaysBefore;*/
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date()); // Use today date
        c.add(Calendar.DATE, 14); // Adding 14 days which is two weeks from the current date
        String output = sdf.format(c.getTime());
        
        
    }
        
	}
